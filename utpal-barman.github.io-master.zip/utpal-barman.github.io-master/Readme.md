# Portfolio of Utpal Barman

This is my personal portfolio site. This is made with HTML, CSS and JS.

⭐ Star this on GitHub — it helps!

## Tools used

- Bootstrap
- JQuery
- Slick JS
- CounterUp JS
- Animate JS
- Github API
- Easing JS
- Typed JS

## Link

[utpal-barman.github.io](https://utpal-barman.github.io)

## Screenshot

![https://utpal-barman.github.io](https://github.com/utpal-barman/utpal-barman.github.io/blob/master/screenshot/screenshot.png)

## Spread the word :hatched_chick:

To learn more about me, join the conversation:

- [LinkedIn](https://www.linkedin.com/in/utpal-barman/)
- [Skype](https://join.skype.com/invite/YKZe1ad0yuyK)
- [Telegram](https://t.me/utpal_barman)
- [Facebook](https://www.facebook.com/utpal777)
- [Instagram](https://www.instagram.com/utpal_barman_/)

## Contributor

<!-- prettier-ignore-start -->
<!-- markdownlint-disable -->
<a href="https://www.linkedin.com/in/utpal-barman/"><img src="https://github.com/utpal-barman/ushop/raw/master/utpal-barman.png" width="100px;" alt=""/>
<br />
<b>Utpal Barman</b></a>
<br/>
<i>Software Engineer</i>
<br/>
Email: <a href="mailto:utpal.barman.bd@gmail.com">utpal.barman.bd@gmail.com</a>


<!-- markdownlint-enable -->
<!-- prettier-ignore-end -->
